function playGame() {
	const gameContainer = document.getElementById('game-container');
	gameContainer.classList.toggle('show');
}
const playGameBtn = document.getElementById('play-game-btn');
playGameBtn.addEventListener('click', playGame);

const showInstructionBtn = document.getElementById('show-instructions-btn');
showInstructionBtn.addEventListener('click', showInstructions);

function showInstructions() {
	const instructionsP = document.getElementById('instructions');
	console.log(instructionsP)
	instructionsP.classList.toggle('show')
}